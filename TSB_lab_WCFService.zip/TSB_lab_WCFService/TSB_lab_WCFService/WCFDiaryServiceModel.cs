namespace TSB_lab_WCFService
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class WCFDiaryServiceModel : DbContext
    {
        public WCFDiaryServiceModel()
            : base("name=WCFDiaryServiceModel")
        {
        }

        public virtual DbSet<WCFDiaryContent> WCFDiaryContent { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<WCFDiaryContent>()
                .Property(e => e.Entry)
                .IsUnicode(false);
        }
    }
}
