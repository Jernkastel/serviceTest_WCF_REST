﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace TSB_lab_WCFService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface IWCFDiaryService
    {
        [OperationContract]
        List<WCFDiaryContentData> GetDiaryData();
    }

    // Use a data contract as illustrated in the sample below to add composite types to service operations.
    [DataContract]
    public class WCFDiaryContentData
    {
        [DataMember]
        public int Id { get; set; }

        [DataMember]
        public string Author { get; set; }

        [DataMember]
        public DateTime Date { get; set; }

        [DataMember]
        public string Entry { get; set; }

        [DataMember]
        public bool Important { get; set; }
    }

}
