namespace TSB_lab_WCFService
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("WCFDiaryContent")]
    public partial class WCFDiaryContent
    {
        public int Id { get; set; }

        [Required]
        [StringLength(50)]
        public string Author { get; set; }

        public DateTime Date { get; set; }

        [Column(TypeName = "text")]
        [Required]
        public string Entry { get; set; }

        public bool Important { get; set; }
    }
}
