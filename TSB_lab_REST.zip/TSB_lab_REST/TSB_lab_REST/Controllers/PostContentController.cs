﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using TSB_lab_REST;

namespace TSB_lab_REST.Controllers
{
    public class PostContentController : ApiController
    {
        private PostModel db = new PostModel();

        // GET: api/PostContent
        public IQueryable<PostContent> GetPostContent()
        {
            return db.PostContent;
        }

        // GET: api/PostContent/5
        [ResponseType(typeof(PostContent))]
        public IHttpActionResult GetPostContent(int id)
        {
            PostContent postContent = db.PostContent.Find(id);
            if (postContent == null)
            {
                return NotFound();
            }

            return Ok(postContent);
        }

        // PUT: api/PostContent/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutPostContent(int id, PostContent postContent)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != postContent.Id)
            {
                return BadRequest();
            }

            db.Entry(postContent).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!PostContentExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/PostContent
        [ResponseType(typeof(PostContent))]
        public IHttpActionResult PostPostContent(PostContent postContent)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.PostContent.Add(postContent);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = postContent.Id }, postContent);
        }

        // DELETE: api/PostContent/5
        [ResponseType(typeof(PostContent))]
        public IHttpActionResult DeletePostContent(int id)
        {
            PostContent postContent = db.PostContent.Find(id);
            if (postContent == null)
            {
                return NotFound();
            }

            db.PostContent.Remove(postContent);
            db.SaveChanges();

            return Ok(postContent);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool PostContentExists(int id)
        {
            return db.PostContent.Count(e => e.Id == id) > 0;
        }
    }
}