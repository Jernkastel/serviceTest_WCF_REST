namespace TSB_lab_REST
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("PostContent")]
    public partial class PostContent
    {
        public int Id { get; set; }

        [Required]
        [StringLength(50)]
        public string Author { get; set; }

        [Column(TypeName = "text")]
        [Required]
        public string Post { get; set; }

        public bool Important { get; set; }
    }
}
